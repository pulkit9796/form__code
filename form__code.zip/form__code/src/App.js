import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import Fgroup from './components/formgroup'
import TR from './components/tableRow'


class App extends React.Component {
  state = {
    "data": [
    //   {
    //   "CustomerId": 1,
    //   "Name": "a",
    //   "Email": "a@1.com",
    //   "Contact": "11111",
    //   "AccountType": "save1"
    // },
    // {
    //   "CustomerId": 2,
    //   "Name": "b",
    //   "Email": "b@2.com",
    //   "Contact": "22222",
    //   "AccountType": "curr2"
    // }
  ]


  }
  tabfiller = (obj) => {
    let arr = this.state.data
    arr.push(obj)
    this.setState({
      "data": arr

    }

    )
  }


  tabremover = (id) => {
    console.log(id)
    let arr = this.state.data.filter((cont,index)=>{return cont.CustomerId!==id})
    
    this.setState({
      "data": arr

    }

    )
  }


  render() {
    return (
      <div>
        <div class="container-fluid">
          <Fgroup funca={this.tabfiller} funcr={this.tabremover} />

        </div>

        <div class="container-fluid">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col">Customer Id</th>
                <th scope="col">Name</th>
                <th scope="col">Email</th>
                <th scope="col">Contact</th>
                <th scope="col">Account Type</th>
              </tr>
            </thead>
            <tbody >
              {this.state.data.map(
                (content) => <TR value={content} />
              )}


            </tbody>
          </table>


        </div>


        

      </div>


    )
  }

}

export default App;
