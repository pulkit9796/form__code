import React, {Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";


class TR extends Component{
        render(){
            return (
                
                    <tr>
                    <td>{this.props.value.CustomerId}</td>
                    <td>{this.props.value.Name}</td>
                    <td>{this.props.value.Email}</td>
                    <td>{this.props.value.Contact}</td>
                    <td>{this.props.value.AccountType}</td>
                </tr>
                
            )
        }
}

export default TR;