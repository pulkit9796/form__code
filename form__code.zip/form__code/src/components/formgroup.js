import React, {Component} from 'react';
import "bootstrap/dist/css/bootstrap.min.css";




  

class Fgroup extends Component{
    
    state = {
        detail: {
            "CustomerId": 0,
            "Name": "",
            "Email": "",
            "Contact": "",
            "AccountType": ""
        },
        id: 0
    }
    

    editor= (e) =>{
        this.setState({
        detail:{ ...this.state.detail,
        [e.target.name]:e.target.value
        }
            

        })

    }

    edit= (e) =>{
        this.setState({
        [e.target.name]:e.target.value
            

        })

    }
    

    adder=()=> this.props.funca(this.state.detail)
    remover=()=> this.props.funcr(this.state.id)
             

       

    

        render(){
            return (
                <div>
                <div class="row">
                    <div class="col-md-12">

                    <div class="row" style={{ marginBottom: "10px" }}>
                    <div class="col-md-3" align="right">
                        <label>Customer Id:</label>
                    </div>
                    <div class="col-md-9">
                        <input onChange={this.editor} class="form-control" name={"CustomerId"} value={this.state.detail.CustomerId} />
                    </div>
                </div>



                <div class="row" style={{ marginBottom: "10px" }}>
                    <div class="col-md-3" align="right">
                        <label>Name:</label>
                    </div>
                    <div class="col-md-9">
                        <input onChange={this.editor} class="form-control" name={"Name"} value={this.state.detail.Name} />
                    </div>
                </div>

                <div class="row" style={{ marginBottom: "10px" }}>
                    <div class="col-md-3" align="right">
                        <label>Email:</label>
                    </div>
                    <div class="col-md-9">
                        <input onChange={this.editor} class="form-control" name={"Email"} value={this.state.detail.Email} />
                    </div>
                </div>


                <div class="row" style={{ marginBottom: "10px" }}>
                    <div class="col-md-3" align="right">
                        <label>Contact:</label>
                    </div>
                    <div class="col-md-9">
                        <input onChange={this.editor} class="form-control" name={"Contact"} value={this.state.detail.Contact} />
                    </div>
                </div>

                <div class="row" style={{ marginBottom: "10px" }}>
                    <div class="col-md-3" align="right">
                        <label>Account Type:</label>
                    </div>
                    <div class="col-md-9">
                        <input onChange={this.editor} class="form-control" name={"AccountType"} value={this.state.detail.AccountType} />
                    </div>
                </div>






                        <div class="row" style={{ marginBottom: "10px" }}>
                            <div class="col-md-3" align="right">

                            </div>
                            <div class="col-md-3">
                                <div align="left">
                                    <div onClick={this.adder}class="btn btn-primary" style={{ backgroundColor: "blue", justifyContent: "center" }}>Add
                                    customer</div>
                                </div>
                            </div>
                            <div class="col-md-3" align="right">
                                <input onChange={this.edit} class="form-control" name={"id"} value={this.state.id} />
                            </div>
                            <div class="col-md-3">
                                <div align="left">
                                    <div onClick={this.remover} class="btn btn-primary" style={{ backgroundColor: "red", justifyContent: "center" }}>Remove
                                    Customer</div>
                                </div>
                            </div>
                        </div>







                    </div>

                </div>









                
                </div>
            )
        }
}

export default Fgroup;